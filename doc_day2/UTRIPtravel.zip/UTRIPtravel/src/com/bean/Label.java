package com.bean;

public class Label {

//	/* ��ǰ��ǩ��ID */
//	private String label_ID;
	/* ��ǰ��ǩ��Ӧ������ID */
	private String attract_ID;
	/* ��ǩ������ */
	private String label;
	
	
	public Label(String attract_ID, String label) {
		super();
		
//		this.label_ID = label_ID;
		this.attract_ID = attract_ID;
		this.label = label;
	}


//	public String getLabel_ID() {
//		return label_ID;
//	}
//
//
//	public void setLabel_ID(String label_ID) {
//		this.label_ID = label_ID;
//	}


	public String getAttract_ID() {
		return attract_ID;
	}


	public void setAttract_ID(String attract_ID) {
		this.attract_ID = attract_ID;
	}


	public String getLabel() {
		return label;
	}


	public void setLabel(String label) {
		this.label = label;
	}
	
	
	
}
