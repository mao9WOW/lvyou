package com.bean;

public class User {

	String user_ID;
	String user_name;
	String password;
	String label;
	String user_gender;
	String user_tel;
	String user_email;
	String user_address;
	String header;
	
	/**
	 * �޲������캯��
	 */
	public User() {
		super();
	}
	
	/**
	 * ����Ա�Ĺ��캯��
	 * @param user_ID 
	 * @param user_name
	 * @param password
	 */
	private User(String ID , String name , String password) {
		super();
		
		this.user_ID = ID;
		this.user_name = name;
		this.password = password;
		this.label = "admin";
	}
	
	
	/**
	 * �ο͵Ĺ��캯��
	 * @param ID
	 * @param name
	 * @param password
	 * @param gender
	 * @param tel
	 * @param email
	 * @param address
	 * @param header
	 */
	public User(String ID , String name , String password, String gender, String tel , String email, String address, String header) {
		super();
		
		this.user_ID = ID;
		this.user_name = name;
		this.password = password;
		this.label = "tourist";
		this.user_gender= gender;
		this.user_tel = tel;
		this.user_email = email;
		this.user_address = address;
		this.header = header;
	}


	
	
	public String getUser_ID() {
		return user_ID;
	}


	public void setUser_ID(String user_ID) {
		this.user_ID = user_ID;
	}


	public String getUser_name() {
		return user_name;
	}


	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getLabel() {
		return label;
	}


	public void setLabel(String label) {
		this.label = label;
	}


	public String getUser_gender() {
		return user_gender;
	}


	public void setUser_gender(String user_gender) {
		this.user_gender = user_gender;
	}


	public String getUser_tel() {
		return user_tel;
	}


	public void setUser_tel(String user_tel) {
		this.user_tel = user_tel;
	}


	public String getUser_email() {
		return user_email;
	}


	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}


	public String getUser_address() {
		return user_address;
	}


	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}


	public String getHeader() {
		return header;
	}


	public void setHeader(String header) {
		this.header = header;
	}
	
	
	public String toString() {
		String str = "";
		str += "user_ID :" + user_ID;
		str += " | user_name :" + user_name;
		str += " | password :" + password;
		str += " | label : " + label;
		str += " | user_gender : " + user_gender;
		str += " | user_tel : " + user_tel;
		str += " | user_email : " + user_email;
		str += " | user_adderss" + user_address;
		return str;
	}

}
