package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.User;
import com.db.DAO.UserDAO;

/**
 * Servlet implementation class LoginDo
 */
@WebServlet("/LoginDo")
public class LoginDo extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public LoginDo() {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		System.out.println("ok");
//		response.sendRedirect("index.jsp");//������
		
		String name = request.getParameter("Uname");
		String password = request.getParameter("Upassword");
		System.out.println(name + "\n" + password);
		
//		UserDAO userDAO = new UserDAO();//����db��
//		ArrayList<User> userList = userDAO.selectByName(name);
//		if(userList!=null){//���鵽��name
//			User user = userList.get(0);
//			
//			//���password��ȷ
//			if(user.getPassword()==password){
//				//�ǹ���Ա
//				if(user.getLabel().equals("admin"))
//			request.getRequestDispatcher("����Ա��ҳ.jsp").forward(request,response);
//				else//��Ȼ���û�
//			request.getRequestDispatcher("�û���ҳ.jsp").forward(request,response);
//		  }
//			else {//���������
//				//----------------����ȱ��һ����ʾ�������Ķ���
//				System.err.println("�������");
//				request.getRequestDispatcher("login.jsp").forward(request,response);;
//			}
//	   }
//		else{
//			//----------------����ȱ��һ����ʾû�и��û��Ķ���
//			System.err.println("�޴��û�");
//			request.getRequestDispatcher("login.jsp").forward(request,response);
//		}
//		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("ok");
		request.getRequestDispatcher("index.jsp").forward(request,response);

	}
	
}