package com.db.DAO;

public class AttractionDAO {

}
