package com.db.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.Attraction;
import com.bean.Label;
import com.db.op.IDUS;
import com.db.op.SQL;

public class LabelDAO {
	
	private IDUS idus;
	
	
	public LabelDAO()  {
		super();
		this.idus = new IDUS();
	}
	
	
	/**
	 * ����һ����ǩ
	 * @param label Ҫ���ӵı�ǩ��bean����
	 */
	public void insert(Label label) {
		
		try {
			String[] attribute = {"attract_ID" , "label"};
			PreparedStatement ps = idus.insert("label", attribute);
			ps.setString(1, label.getAttract_ID());
			ps.setString(2, label.getLabel());
			
			int row = ps.executeUpdate();//ִ�и��²�����������Ӱ�������
			if(row > 0) {
				System.out.println("�ɹ�������" + row + "������");
			}
			ps.close();
			idus.closeConnection();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * �����ݿ���ɾ��һ����ǩ
	 * @param label  Ҫɾ���ı�ǩ
	 */
	public void delete(Label label) {
		try {
			String con = "attraction_ID = ? AND label = ?";
			PreparedStatement ps = idus.delete("label", con);
			ps.setString(1 , label.getAttract_ID());
			ps.setString(2, label.getLabel());
			ps.executeUpdate();//ִ�и��²�����������Ӱ�������
			ps.close();
			idus.closeConnection();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	/**
	 * ͨ��������ID��ѯ������Ӧ��label�б�
	 * @param attract_ID ������ID
	 * @return ��ѯ����ID�б�
	 */
	public ArrayList<com.bean.Label> selectLabelList(String attract_ID) {
		
		try {
			String[] con = {"attract_ID = " + attract_ID};
			
			ArrayList<com.bean.Label> list = new ArrayList<com.bean.Label>();
			
			ResultSet rs = idus.select("label", con);
			
			while(rs.next()) {
				String str1 = rs.getString("attract_ID");
				String str2 = rs.getString("label");
				
				com.bean.Label label = new Label(str1, str2);
				list.add(label);
			}
			
			rs.close();
			idus.closeStatement();
			idus.closeConnection();
			
			return list;
		} catch (SQLException e) {
			// TODO: handle exception
		}
		
		return null;
	}

	
//	public ArrayList<Attraction> selectAttractionListByLabel(String label) {
//		
//		try {
//			/* ��ѯ��ͬlabel�б� */
//			String[] con = {"label = " + label};
//			ArrayList<Label> labelList = new ArrayList<Label>();
//			ResultSet rs = idus.select("label", con);
//			
//			while(rs.next()) {
//				String str1 = rs.getString("attract_ID");
//				String str2 = rs.getString("label");
//
//				labelList.add(new Label(str1, str2));
//			}
//			
//			/* ͨ��labelList��ȡAttraction�б� */
//			ArrayList<Attraction> attractionList = new ArrayList<Attraction>();
//			
//			for (int i = 0; i < labelList.length; i++) {
//				ArrayList<Attraction> list = new Attra
//			}
//			
//			rs.close();
//			idus.closeStatement();
//			idus.closeConnection();
//			
//			//return list;
//		} catch (SQLException e) {
//			// TODO: handle exception
//		}
//		
//		return null;
//	}
}
