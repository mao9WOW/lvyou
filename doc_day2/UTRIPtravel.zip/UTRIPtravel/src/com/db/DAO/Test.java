package com.db.DAO;

import java.util.ArrayList;

import com.bean.User;

public class Test {
	
	public static void main(String[] args)  
	{
		System.out.println(">>>>>>#UserDAO#");
		UserDAO userDAO = new UserDAO();
		ArrayList<User> userList = userDAO.selectByName("XieZhiwei");
		System.out.println(userList.size());
		System.out.println(userList.get(0).toString());
		
	}
}
