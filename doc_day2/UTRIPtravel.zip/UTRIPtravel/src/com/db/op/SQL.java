package com.db.op;

public class SQL {
	
	public String selectSQL(String table_name) {
		
		String sql = "SELECT all From " + table_name;
		
		return sql;
	}
	
	
	public  String selectSQL(String table_name , String goal ) {

		String sql = "SELECT " + goal;
		sql += " FROM " + table_name;
		
		return sql;
	}
	
	
	public String selectSQL(String table_name , String[] con) {

		String sql = "SELECT * FROM ";
		sql +=  table_name;
		sql += " WHERE ";
		for(int i = 0 ; i < con.length ; i++) {
			sql += con[i];
			if(i < con.length - 1) sql += " AND ";
		}
		
		//sql = "SELECT * FROM user WHERE user_name = 'XieZhiwei'";
		System.out.println("getSQL>>>>>" + sql);
		
		return sql;
		
	}

	
//	public String insertSQL(String table_name , int value_num) {
//		
//		String sql = "INSERT INTO";
//		sql += table_name;
//		sql += "VALUES (";
//		for(int i = 0 ; i < value_num ; i++) {
//			
//		}
//		sql += ")";
//		
//		return sql;
//	}
	
	
	public String insertSQL(String table_name , String[] attribute) {
		
		String sql = "INSERT INTO ";
		sql += table_name + " ( ";
		for(int i = 0 ; i < attribute.length ; i++) {
			sql +=  attribute[i];
			if(i < attribute.length - 1) sql += " , ";
		}
		sql += " ) VALUES ( ";
		for(int i = 0 ; i < attribute.length ; i++) {
			sql += " ? ";
			if(i < attribute.length - 1) sql += " , ";
		}
		sql += " ) ";
		
		return sql;
	}
	
	
	public String updateSQL(String table_name , String[] attribute , String con) {
		
		String sql = "UPDATE ";
		sql += table_name;
		sql += " SET ";
		for(int i = 0 ; i < attribute.length ; i++) {
			sql += attribute + " = ? ";
			if(i < attribute.length) sql += " , ";
		}
		sql += " WHERE " + con;
		
		return sql;
	}
	
	
	public String deleteSQL(String table_name , String con) {
		
		String sql = "DELETE FROM ";
		sql += table_name;
		sql += " WHERE " + con;
		
		return sql;
	}

}
