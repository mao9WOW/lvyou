package com.bean;

import java.sql.Time;
import java.util.ArrayList;

public class Attraction {
	
	/* ������ID */
	private String attract_ID;
	/* ���������֣�Ψһ�� */
	private String attract_name;
	/* ������ַ */
	private String address;
	/* ������ϵ�绰 */
	private String tel;
	/* �������� */
	private String email;
	/* �����ȼ���1~5�� */
	private int level;
	/* ������Ʊ�۸� */
	private float price;
	/* ������ */
	private int like_num;
	/* ����� */
	private int views;
	/* ��������ʱ�� */
	private int play_time;
	/* ��������ʱ�� */
	private Time start;
	/* �����ر�ʱ�� */
	private Time end;
	/* �����ķ��� */
	private String image_ID;
	
	/* �����ı�ǩ�б� */
	private ArrayList<Label> labelList;
	
	/* ������ͼƬ�б� */
	private ArrayList<Image> imageList;
	
	
	public Attraction(String attract_ID, String attract_name, String address, 
			String tel, String email, int level, float price, int like_num, int views, 
			int play_time, Time start, Time end, String image_ID) {
		super();
		
		this.attract_ID = attract_ID;
		this.attract_name = attract_name;
		this.address = address;
		this.tel = tel;
		this.email = email;
		this.level = level;
		this.price = price;
		this.like_num = like_num;
		this.views = views;
		this.play_time = play_time;
		this.start = start;
		this.end = end;
		this.image_ID = image_ID;
	}


	public String getAttract_ID() {
		return attract_ID;
	}
	
	
	public ArrayList<Label> getLabelList() {
		
	}
	
	
	public ArrayList<Image> getImageList() {
		
	}
	


	public void setAttract_ID(String attract_ID) {
		this.attract_ID = attract_ID;
	}


	public String getAttract_name() {
		return attract_name;
	}


	public void setAttract_name(String attract_name) {
		this.attract_name = attract_name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getTel() {
		return tel;
	}


	public void setTel(String tel) {
		this.tel = tel;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public int getLevel() {
		return level;
	}


	public void setLevel(int level) {
		this.level = level;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	public int getLike_num() {
		return like_num;
	}


	public void setLike_num(int like_num) {
		this.like_num = like_num;
	}


	public int getViews() {
		return views;
	}


	public void setViews(int views) {
		this.views = views;
	}


	public int getPlay_time() {
		return play_time;
	}


	public void setPlay_time(int play_time) {
		this.play_time = play_time;
	}


	public Time getStart() {
		return start;
	}


	public void setStart(Time start) {
		this.start = start;
	}


	public Time getEnd() {
		return end;
	}


	public void setEnd(Time end) {
		this.end = end;
	}


	public String getImage_ID() {
		return image_ID;
	}


	public void setImage_ID(String image_ID) {
		this.image_ID = image_ID;
	}

}
