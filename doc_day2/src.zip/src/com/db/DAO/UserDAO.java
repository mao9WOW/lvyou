package com.db.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.db.op.IDUS;

public class UserDAO {
	
	private IDUS idus;
	
	
	public UserDAO()  {
		super();
		this.idus = new IDUS();
	}
	
	
	/**
	 * ͨ���û�����ѯUser
	 * @param user_name �û���
	 * @return ��ѯ����User�б�
	 */
	public ArrayList<com.bean.User> selectByName(String user_name) {
		
		try {
			String[] con = {"user_name = " + user_name};
			
			ArrayList<com.bean.User> list = new ArrayList<com.bean.User>();
			
			ResultSet rs = idus.select("user", con);
			
			while(rs.next()) {  //ʵ����list����
				com.bean.User user = new com.bean.User();//ʵ����User����
				user.setUser_ID(rs.getString("user_ID"));
				user.setUser_name(rs.getString("user_name"));
				rs.getString("password");
				rs.getString("label");
				user.setLabel("tourist");
				user.setUser_gender(rs.getString("user_gender"));
				user.setUser_tel(rs.getString("user_tel"));
				user.setUser_email(rs.getString("user_email"));
				user.setUser_address(rs.getString("user_address"));
				user.setHeader(rs.getString("header"));
				
				list.add(user);
			}
			rs.close();
			idus.closeStatement();
			idus.closeConnection();
			
			return list;
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	/**
	 * ͨ���û�ID��ѯUser
	 * @param user_ID �û�ID
	 * @return ��ѯ����User�б�
	 */
	public ArrayList<com.bean.User> selectByID(String user_ID) {
		
		try {
			String[] con = {"user_ID = " + user_ID};
			
			ArrayList<com.bean.User> list = new ArrayList<com.bean.User>();
			
			ResultSet rs = idus.select("user", con);
			
			while(rs.next()) {  //ʵ����list����
				com.bean.User user = new com.bean.User();//ʵ����User����
				user.setUser_ID(rs.getString("user_ID"));
				user.setUser_name(rs.getString("user_name"));
				rs.getString("password");
				rs.getString("label");
				user.setLabel("tourist");
				user.setUser_gender(rs.getString("user_gender"));
				user.setUser_tel(rs.getString("user_tel"));
				user.setUser_email(rs.getString("user_email"));
				user.setUser_address(rs.getString("user_address"));
				user.setHeader(rs.getString("header"));
				
				list.add(user);
			}
			rs.close();
			idus.closeStatement();
			idus.closeConnection();
			
			return list;
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return null;
	}

	
	/**
	 * �����ݿ��в���һ��User��Ϣ��ע�ᣩ
	 * @param user Ҫ�����user bean����
	 */
	public void insert(com.bean.User user) {
		
		try {
			String[] attribute = {"user_ID" , "user_name" , "password" , "label" , "user_gender" , "user_tel" , "user_email" , "user_address" , "header"};
			PreparedStatement ps = idus.insert("user", attribute);
			ps.setString(1, user.getUser_ID());
			ps.setString(2, user.getUser_name());
			ps.setString(3, user.getPassword());
			ps.setString(4, user.getLabel());
			ps.setString(5, user.getUser_gender());
			ps.setString(6, user.getUser_tel());
			ps.setString(7, user.getUser_email());
			ps.setString(8, user.getUser_address());
			ps.setString(9, user.getHeader());
			
			int row = ps.executeUpdate();//ִ�и��²�����������Ӱ�������
			if(row > 0) {
				System.out.println("�ɹ�������" + row + "������");
			}
			ps.close();
			idus.closeConnection();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	/**
	 * �����޸�User����Ϣ
	 * @param user Ҫ�޸ĵ�User���µ�bean���󣨲��޸ĵ����԰�ԭ�������ݱ��棩
	 */
	public void update(com.bean.User user) {
		
		try {
			String[] attribute = {"user_ID" , "user_name" , "password" , "label" , "user_gender" , "user_tel" , "user_email" , "user_address" , "header"};
			String con = "user_ID = ?";
			PreparedStatement ps = idus.update("user", attribute, con);
			ps.setString(1, user.getUser_ID());
			ps.setString(2, user.getUser_name());
			ps.setString(3, user.getPassword());
			ps.setString(4, user.getLabel());
			ps.setString(5, user.getUser_gender());
			ps.setString(6, user.getUser_tel());
			ps.setString(7, user.getUser_email());
			ps.setString(8, user.getUser_address());
			ps.setString(9, user.getHeader());
			ps.setString(10, user.getUser_ID());
			
			int row = ps.executeUpdate();//ִ�и��²�����������Ӱ�������
			if(row > 0) {
				System.out.println("�ɹ��޸���" + row + "������");
			}
			ps.close();
			idus.closeConnection();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}


	/**
	 * ͨ���û���ɾ��һ��User��Ϣ
	 * @param user_name Ҫɾ����User��user_name
	 */
	public void delete(String user_name) {
		
		try {
			String con = "user_name = ?";
			PreparedStatement ps = idus.delete("user", con);
			ps.setString(1 , user_name);
			ps.executeUpdate();//ִ�и��²�����������Ӱ�������
			ps.close();
			idus.closeConnection();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	/**
	 * ����һ���µ�user_ID
	 * @return ���ɵ�user_ID
	 */
	public String newUserID() {
		String str = "";
		for(int i = 0 ; i < 9999999 ; i++) {
			String n = String.valueOf(i);
			str += "1";
			for(int j = 0 ; j < 7-n.length() ; j++) str += "0";
			str += n;
			
			//��user���в�ѯuser_IDΪstr���в��ж��Ƿ����
			if(selectByID(str).isEmpty()) {
				return str;
			}
		}
		
		return null;
	}
	
	
	/**
	 * �ж�user_name�Ƿ������ݿ����Ѵ���
	 * @param name
	 * @return
	 */
	public boolean nameIsExist(String name) {
		
		//�жϵ�ǰuser_name�Ƿ����
		if(selectByName(name).isEmpty()) {
			return false;
		}
		return true;
	}
	
}
