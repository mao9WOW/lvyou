package com.db.op;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * �����ݿ��һ�β���
 * ͨ��SQL���
 * 
 * @author ����ΰ
 */
public class IDUS {
	
	/* ���ݿ����� */
	private Connection conn = null;
	
	/* SQL�������ڻ�ȡSQL��� */
	private SQL sql;
	
	/* Statement���� */
	private Statement stmt;
	
	
	/**
	 * ���캯�����������ݿ�
	 */
	public IDUS() {
		super();
		
		conn = DBHelper.getConnection();
		try {
			stmt = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sql = new SQL();
	}
	
	
//	/**
//	 * ִ��SQL��䣬����Statement����
//	 * @param sql SQL���
//	 * @return Statement����
//	 */
//	public Statement getStatement() {
//		try {
//			Statement stmt = conn.createStatement();
//			conn.close();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return null;
//	}
	
	
//	private PreparedStatement doSQL(String sql) {
//		try {
//			return conn.prepareStatement(sql);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return null;
//	}
	
	
	public ResultSet select(String table_name) {
		try {
			return stmt.executeQuery(sql.selectSQL(table_name));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	public  ResultSet select(String table_name , String goal ) {
		try {
			return stmt.executeQuery(sql.selectSQL(table_name, goal));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	public ResultSet select(String table_name , String[] con) {
		try {
			return stmt.executeQuery(sql.selectSQL(table_name, con));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	
//	public PreparedStatement insert(String table_name , String[] value) {
//		return doSQL(sql.insertSQL(table_name, value));
//	}
	
	
	public PreparedStatement insert(String table_name , String[] attribute) {
		try {
			return conn.prepareStatement(sql.insertSQL(table_name, attribute));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	public PreparedStatement update(String table_name , String[] attribute , String con) {
		//return doSQL(sql.updateSQL(table_name, data, con));
		try {
			return conn.prepareStatement(sql.updateSQL(table_name, attribute, con));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public PreparedStatement delete(String table_name , String con) {
		try {
			return conn.prepareStatement(sql.deleteSQL(table_name, con));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public void closeConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void closeStatement() {
		try {
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
