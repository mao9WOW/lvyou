package com.bean;

/**
 * �û��Ծ���������
 * 
 * @author ����ΰ
 */
public class Comment {

	/** ���۵�ID */
	private String comment_ID;
	
	/** ���������۵�User��ID */
	private String user_ID;
	
	/** �����۶�Ӧ�ľ�����ID */
	private String attract_ID;
	
	/** ����Ӧ���������� */
	private int score;
	
	/** ���۵����� */
	private String content;
	
	public Comment() {
		super();
	}
	
	public Comment(String user_ID , String attract_ID , int score , String content) {
		super();
		this.user_ID = user_ID;
		this.attract_ID = attract_ID;
		this.score = score;
		this.content = content;
	}

	/**
	 * @return the comment_ID
	 */
	public String getComment_ID() {
		return comment_ID;
	}

	/**
	 * @param comment_ID the comment_ID to set
	 */
	public void setComment_ID(String comment_ID) {
		this.comment_ID = comment_ID;
	}

	/**
	 * @return the user_ID
	 */
	public String getUser_ID() {
		return user_ID;
	}

	/**
	 * @param user_ID the user_ID to set
	 */
	public void setUser_ID(String user_ID) {
		this.user_ID = user_ID;
	}

	/**
	 * @return the attract_ID
	 */
	public String getAttract_ID() {
		return attract_ID;
	}

	/**
	 * @param attract_ID the attract_ID to set
	 */
	public void setAttract_ID(String attract_ID) {
		this.attract_ID = attract_ID;
	}

	/**
	 * @return the score
	 */
	public int getScore() {
		return score;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(int score) {
		this.score = score;
	}

	/**
	 * @return the content
	 */
	public String getContent() {
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}
	
}
