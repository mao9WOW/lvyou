package com.bean;

/**
 * ����С���ڵĳ�Ա
 * 
 * @author ����ΰ
 */
public class GroupMember {

	/** ��������С���ID */
	private String group_ID;
	
	/** ��ǰ��Ա���û�ID */
	private String user_ID;

	public GroupMember() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GroupMember(String group_ID, String user_ID) {
		super();
		this.group_ID = group_ID;
		this.user_ID = user_ID;
	}

	/**
	 * @return the group_ID
	 */
	public String getGroup_ID() {
		return group_ID;
	}

	/**
	 * @param group_ID the group_ID to set
	 */
	public void setGroup_ID(String group_ID) {
		this.group_ID = group_ID;
	}

	/**
	 * @return the user_ID
	 */
	public String getUser_ID() {
		return user_ID;
	}

	/**
	 * @param user_ID the user_ID to set
	 */
	public void setUser_ID(String user_ID) {
		this.user_ID = user_ID;
	}
	
}
