package com.bean;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Image {

	/** ͼƬ��ID */
	private String image_ID;
	
	/** ͼƬ��Ӧ�ľ����ı��� */
	private String attract_ID;
	
	/** ͼƬ�Ĵ洢·��*/
	private String image_adr;
	
	public Image() {
		super();
	}
	
	public Image(String attract_ID, String image_adr) {
		super();
		
		this.attract_ID = attract_ID;
		this.image_adr = image_adr;
	}
	
	/**
	 * ��ȡ��ǰ�����Ӧ��ͼƬ
	 * @return ��ȡ����ͼƬ
	 */
	public java.awt.Image getImage() {
		try {
			return ImageIO.read(new File(image_adr));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * @return the image_ID
	 */
	public String getImage_ID() {
		return image_ID;
	}

	/**
	 * @param image_ID the image_ID to set
	 */
	public void setImage_ID(String image_ID) {
		this.image_ID = image_ID;
	}

	/**
	 * @return the attract_ID
	 */
	public String getAttract_ID() {
		return attract_ID;
	}

	/**
	 * @param attract_ID the attract_ID to set
	 */
	public void setAttract_ID(String attract_ID) {
		this.attract_ID = attract_ID;
	}

	/**
	 * @return the image_adr
	 */
	public String getImage_adr() {
		return image_adr;
	}

	/**
	 * @param image_adr the image_adr to set
	 */
	public void setImage_adr(String image_adr) {
		this.image_adr = image_adr;
	}
	
}
