package com.bean;

import java.util.ArrayList;

import com.db.DAO.AttractionDAO;

public class Label {

	/** ��ǰ��ǩ��Ӧ������ID */
	private String attract_ID;
	
	/** ��ǩ������ */
	private String label;
	
	public Label(String attract_ID, String label) {
		super();
		this.attract_ID = attract_ID;
		this.label = label;
	}

	/**
	 * @return the attract_ID
	 */
	public String getAttract_ID() {
		return attract_ID;
	}

	/**
	 * @param attract_ID the attract_ID to set
	 */
	public void setAttract_ID(String attract_ID) {
		this.attract_ID = attract_ID;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	
}
