package com.bean;

import java.sql.Timestamp;
import java.util.ArrayList;

import com.db.DAO.GroupMemberDAO;

/**
 * һ�������ε�����С��
 * 
 * @author ����ΰ
 */
public class TravelGroup {

	/** С��ID */
	private String group_ID;
	
	/** С����������ID */
	private String society_ID;
	
	/** ���������� */
	private String topic;
	
	/** �����ν��� */
	private String description;
	
	/** ����ʱ�� */
	private Timestamp start;
	
	/** ����ʱ�� */
	private Timestamp end;

	public TravelGroup() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TravelGroup(String society_ID, String topic, String description, Timestamp start, Timestamp end) {
		super();
		this.society_ID = society_ID;
		this.topic = topic;
		this.description = description;
		this.start = start;
		this.end = end;
	}
	
	/**
	 * ��ѯ��ǰС������г�Ա
	 * @return ��ѯ���ĳ�Ա�б�
	 */
	public ArrayList<User> getGroupMemberList() {
		return GroupMemberDAO.selectByGroupID(group_ID);
	}

	/**
	 * @return the group_ID
	 */
	public String getGroup_ID() {
		return group_ID;
	}

	/**
	 * @param group_ID the group_ID to set
	 */
	public void setGroup_ID(String group_ID) {
		this.group_ID = group_ID;
	}

	/**
	 * @return the society_ID
	 */
	public String getSociety_ID() {
		return society_ID;
	}

	/**
	 * @param society_ID the society_ID to set
	 */
	public void setSociety_ID(String society_ID) {
		this.society_ID = society_ID;
	}

	/**
	 * @return the topic
	 */
	public String getTopic() {
		return topic;
	}

	/**
	 * @param topic the topic to set
	 */
	public void setTopic(String topic) {
		this.topic = topic;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the start
	 */
	public Timestamp getStart() {
		return start;
	}

	/**
	 * @param start the start to set
	 */
	public void setStart(Timestamp start) {
		this.start = start;
	}

	/**
	 * @return the end
	 */
	public Timestamp getEnd() {
		return end;
	}

	/**
	 * @param end the end to set
	 */
	public void setEnd(Timestamp end) {
		this.end = end;
	}
	
}
