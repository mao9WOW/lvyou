package com.bean;

import java.awt.Image;
import java.lang.reflect.GenericDeclaration;
import java.util.ArrayList;

import com.db.DAO.CommentDAO;
import com.db.DAO.ForumDAO;
import com.db.DAO.GroupMemberDAO;
import com.db.DAO.SocietyDAO;

public class User {

	/** �û�ID */
	private String user_ID;
	
	/** �û���*/
	private String user_name;
	
	/** �û����� */
	private String password;
	
	/** �û���ǩ��admin������Ա��tourist���οͣ� */
	private String label;
	
	/** �û��Ա� */
	private String user_gender;
	
	/** �û���ϵ�绰 */
	private String user_tel;
	
	/** �û����� */
	private String user_email;
	
	/** �û���ס��ַ */
	private String user_address;
	
	/** �û�ͷ��Ĵ洢λ�� */
	private String header;
	
	/**
	 * �޲������캯��
	 */
	public User() {
		super();
	}
	
//	/**
//	 * ����Ա�Ĺ��캯��
//	 * @param user_ID 
//	 * @param user_name
//	 * @param password
//	 */
//	private User(String ID , String name , String password) {
//		super();
//		
//		this.user_ID = ID;
//		this.user_name = name;
//		this.password = password;
//		this.label = "admin";
//	}
	
	
	/**
	 * �ο͵Ĺ��캯��
	 * @param name
	 * @param password
	 * @param gender
	 * @param tel
	 * @param email
	 * @param address
	 * @param header
	 */
	public User(String name , String password, String gender, String tel , String email, String address , String header) {
		super();
		this.user_name = name;
		this.password = password;
		this.label = "tourist";
		this.user_gender= gender;
		this.user_tel = tel;
		this.user_email = email;
		this.user_address = address;
		this.header = header;
	}

	/**
	 * ���ҵ�ǰ�û�����������
	 * @return ���ҵ��������б�
	 */
	public ArrayList<Comment> getCommentList() {
		return CommentDAO.selectByUserID(user_ID);
	}
	
	/**
	 * ���ҵ�ǰ�û�����̳�з�������������
	 * @return ���ҵ�����̳�����б�
	 */
	public ArrayList<Forum> getForumList() {
		return ForumDAO.selectByUserID(user_ID);
	}
	
	/**
	 * ��ѯ��ǰ�û���������������
	 * @return ��ѯ���������б�
	 */
	public ArrayList<Society> getSocietyList() {
		return SocietyDAO.societyByUserID(user_ID);
	}
	
	/** 
	 * ��ѯ��ǰ�û��μӵ���������С��
	 * @return ��ѯ��������С���б�
	 */
	public ArrayList<TravelGroup> getTravelGroupList() {
		return GroupMemberDAO.selectByUserID(user_ID);
	}
	
	/**
	 * @return the user_ID
	 */
	public String getUserID() {
		return user_ID;
	}

	/**
	 * @return the user_name
	 */
	public String getUserName() {
		return user_name;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @return the user_gender
	 */
	public String getUserGender() {
		return user_gender;
	}

	/**
	 * @return the user_tel
	 */
	public String getUserTel() {
		return user_tel;
	}

	/**
	 * @return the user_email
	 */
	public String getUserEmail() {
		return user_email;
	}

	/**
	 * @return the user_address
	 */
	public String getUserAddress() {
		return user_address;
	}

	/**
	 * @return the header
	 */
	public String getHeader() {
		return header;
	}

	/**
	 * @param user_ID the user_ID to set
	 */
	public void setUserID(String user_ID) {
		this.user_ID = user_ID;
	}

	/**
	 * @param user_name the user_name to set
	 */
	public void setUserName(String user_name) {
		this.user_name = user_name;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * @param user_gender the user_gender to set
	 */
	public void setUserGender(String user_gender) {
		this.user_gender = user_gender;
	}

	/**
	 * @param user_tel the user_tel to set
	 */
	public void setUserTel(String user_tel) {
		this.user_tel = user_tel;
	}

	/**
	 * @param user_email the user_email to set
	 */
	public void setUserEmail(String user_email) {
		this.user_email = user_email;
	}

	/**
	 * @param user_address the user_address to set
	 */
	public void setUserAddress(String user_address) {
		this.user_address = user_address;
	}

	/**
	 * @param header the header to set
	 */
	public void setHeader(String header) {
		this.header = header;
	}

	public String toString() {
		String str = "";
		str += "user_ID :" + user_ID;
		str += " | user_name :" + user_name;
		str += " | password :" + password;
		str += " | label : " + label;
		str += " | user_gender : " + user_gender;
		str += " | user_tel : " + user_tel;
		str += " | user_email : " + user_email;
		str += " | user_adderss : " + user_address;
		return str;
	}

}
