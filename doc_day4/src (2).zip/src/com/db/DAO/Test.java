package com.db.DAO;

import com.bean.User;

public class Test {
	
	public static void main(String[] args)  
	{
		System.out.println(">>>>>>#UserDAO#");
		UserDAO userDAO = new UserDAO();
		
		System.out.println("\n>>>selectByName()");
		User user1 = userDAO.selectByName("hefangz");
		if(user1 != null) System.out.println(user1.toString());
		
		System.out.println("\nselectByID()");
		User user2 = userDAO.selectByID("10000002");
		System.out.println(user2.toString());
		
//		System.out.println("\ninsert()");
//		User user3 = new User("MaoZhi" , "123456" , "man" , "xxxxxxxxxxx" , "xxxxxxxxxxx" , "����ʡ������");
//		System.out.println(user3.toString());
//		userDAO.insert(user3);
//		user3 = userDAO.selectByName("MaoZhi");
//		System.out.println(user3.toString());
		
		System.out.println("\ndelete()");
		userDAO.delete("MaoZhi");
		
		System.out.println("\nupdateUserTel()");
		userDAO.updateUserTel("10000001", "18092623461");
		
	}
}
